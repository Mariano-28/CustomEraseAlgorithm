﻿// Copyright (C) 2007-2025 Mariano Ortu <https://www.sicurpas.it/> <https://www.speedcrypt.info/>

using System;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Reflection;

namespace Customtest

{
    public partial class FrmInfo : Form
    {
        #region Constructors

        private FrmMain mainForm;
        public FrmInfo()
        {
            InitializeComponent();
        }
        public FrmInfo(Form callingForm)
        {
            mainForm = callingForm as FrmMain;
            InitializeComponent();
            loadAll();
        }

        #endregion Constructors

        #region Settings
        void loadAll()
        {
            //Form Settings
            Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
            Text = "Info...";
            labPro.Text = "Custom Erase Example";
            MaximizeBox = false;
            MinimizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            panel1.BackColor = Color.Gainsboro;
            labCop.Text = "Author: Mariano Ortu Copyright (c) 2007 - " + DateTime.Now.ToString("yyyy");

            //Linklabel
            linkLabSic.LinkClicked += LinkLabSic_LinkClicked;
            linkLabSpc.LinkClicked += LinkLabSpc_LinkClicked;

            //Button
            btnOk.Click += BtnOk_Click1;
        }

        #endregion Settings

        #region lLinklabels
        private void LinkLabSic_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start(linkLabSic.Text);
        }
        private void LinkLabSpc_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start(linkLabSpc.Text);
        }
        #endregion Linklabels

        #region Button
        private void BtnOk_Click1(object sender, System.EventArgs e)
        {
            Close();
        }
        #endregion Button
    }
}