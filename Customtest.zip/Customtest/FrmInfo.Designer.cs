﻿namespace Customtest
{
    partial class FrmInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOk = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.linkLabSpc = new System.Windows.Forms.LinkLabel();
            this.linkLabSic = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labCop = new System.Windows.Forms.Label();
            this.labPro = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(114, 204);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 30);
            this.btnOk.TabIndex = 10;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.linkLabSpc);
            this.panel1.Controls.Add(this.linkLabSic);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.labCop);
            this.panel1.Controls.Add(this.labPro);
            this.panel1.Location = new System.Drawing.Point(5, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(295, 197);
            this.panel1.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(17, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(260, 3);
            this.label5.TabIndex = 6;
            // 
            // linkLabSpc
            // 
            this.linkLabSpc.AutoSize = true;
            this.linkLabSpc.Location = new System.Drawing.Point(90, 90);
            this.linkLabSpc.Name = "linkLabSpc";
            this.linkLabSpc.Size = new System.Drawing.Size(147, 13);
            this.linkLabSpc.TabIndex = 5;
            this.linkLabSpc.TabStop = true;
            this.linkLabSpc.Text = "https://www.speedcrypt.info/";
            // 
            // linkLabSic
            // 
            this.linkLabSic.AutoSize = true;
            this.linkLabSic.Location = new System.Drawing.Point(90, 110);
            this.linkLabSic.Name = "linkLabSic";
            this.linkLabSic.Size = new System.Drawing.Size(169, 13);
            this.linkLabSic.TabIndex = 4;
            this.linkLabSic.TabStop = true;
            this.linkLabSic.Text = "https://www.sicurpas.it/index.html";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(15, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(262, 26);
            this.label4.TabIndex = 3;
            this.label4.Text = "For questions about my articles you can contact me \r\nat this email address: sicur" +
    "pas@sicurpas.it.Thank you!";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Reference websites:";
            // 
            // labCop
            // 
            this.labCop.AutoSize = true;
            this.labCop.Location = new System.Drawing.Point(30, 40);
            this.labCop.Name = "labCop";
            this.labCop.Size = new System.Drawing.Size(227, 13);
            this.labCop.TabIndex = 1;
            this.labCop.Text = "Author: Mariano Ortu Copyright (c) 2007 - 2024";
            // 
            // labPro
            // 
            this.labPro.AutoSize = true;
            this.labPro.BackColor = System.Drawing.Color.Gainsboro;
            this.labPro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labPro.Location = new System.Drawing.Point(50, 13);
            this.labPro.Name = "labPro";
            this.labPro.Size = new System.Drawing.Size(195, 20);
            this.labPro.TabIndex = 0;
            this.labPro.Text = "Custom Erase Example";
            // 
            // FrmInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 239);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnOk);
            this.Name = "FrmInfo";
            this.Text = "FrmInfo";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.LinkLabel linkLabSpc;
        private System.Windows.Forms.LinkLabel linkLabSic;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labCop;
        private System.Windows.Forms.Label labPro;
    }
}