﻿// Copyright (C) 2007-2025 Mariano Ortu <https://www.sicurpas.it/> <https://www.speedcrypt.info/>

using System;
using System.Windows.Forms;

namespace Customtest
{
    internal static class Program
    {
        /// <summary>
        /// Punto di ingresso principale dell'applicazione.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmMain());
        }
    }
}
