﻿namespace Customtest
{
    partial class FrmMain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtFilepathdel = new System.Windows.Forms.TextBox();
            this.labOrtu = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.infoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labTime = new System.Windows.Forms.Label();
            this.grbAlgdel = new System.Windows.Forms.GroupBox();
            this.btnClearval = new System.Windows.Forms.Button();
            this.labScore = new System.Windows.Forms.Label();
            this.BtnSug = new System.Windows.Forms.Button();
            this.rdbCust2 = new System.Windows.Forms.RadioButton();
            this.rdbCust1 = new System.Windows.Forms.RadioButton();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.cmbCustom = new System.Windows.Forms.ComboBox();
            this.listCustom = new System.Windows.Forms.ListBox();
            this.btnLoaddel = new System.Windows.Forms.Button();
            this.labFilepathdel = new System.Windows.Forms.Label();
            this.labKb = new System.Windows.Forms.Label();
            this.grbDesc = new System.Windows.Forms.GroupBox();
            this.labShrd = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.grbAlgdel.SuspendLayout();
            this.grbDesc.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(100, 342);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 25);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "Delete File..";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // txtFilepathdel
            // 
            this.txtFilepathdel.Location = new System.Drawing.Point(10, 320);
            this.txtFilepathdel.Name = "txtFilepathdel";
            this.txtFilepathdel.Size = new System.Drawing.Size(497, 20);
            this.txtFilepathdel.TabIndex = 0;
            // 
            // labOrtu
            // 
            this.labOrtu.AutoSize = true;
            this.labOrtu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labOrtu.ForeColor = System.Drawing.SystemColors.Highlight;
            this.labOrtu.Location = new System.Drawing.Point(330, 370);
            this.labOrtu.Name = "labOrtu";
            this.labOrtu.Size = new System.Drawing.Size(226, 16);
            this.labOrtu.TabIndex = 279;
            this.labOrtu.Text = "Copyright (C) 2007-2024 Mariano Ortu";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(569, 24);
            this.menuStrip1.TabIndex = 280;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileMenuItem
            // 
            this.fileMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.infoMenuItem,
            this.closeMenuItem});
            this.fileMenuItem.Name = "fileMenuItem";
            this.fileMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileMenuItem.Text = "File";
            // 
            // infoMenuItem
            // 
            this.infoMenuItem.Name = "infoMenuItem";
            this.infoMenuItem.Size = new System.Drawing.Size(104, 22);
            this.infoMenuItem.Text = "Info...";
            // 
            // closeMenuItem
            // 
            this.closeMenuItem.Name = "closeMenuItem";
            this.closeMenuItem.Size = new System.Drawing.Size(104, 22);
            this.closeMenuItem.Text = "Close";
            // 
            // labTime
            // 
            this.labTime.BackColor = System.Drawing.Color.Transparent;
            this.labTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labTime.ForeColor = System.Drawing.Color.Black;
            this.labTime.Location = new System.Drawing.Point(513, 320);
            this.labTime.Name = "labTime";
            this.labTime.Size = new System.Drawing.Size(55, 20);
            this.labTime.TabIndex = 281;
            this.labTime.Text = "00.00.000";
            this.labTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // grbAlgdel
            // 
            this.grbAlgdel.Controls.Add(this.btnClearval);
            this.grbAlgdel.Controls.Add(this.labScore);
            this.grbAlgdel.Controls.Add(this.BtnSug);
            this.grbAlgdel.Controls.Add(this.rdbCust2);
            this.grbAlgdel.Controls.Add(this.rdbCust1);
            this.grbAlgdel.Controls.Add(this.progressBar1);
            this.grbAlgdel.Controls.Add(this.cmbCustom);
            this.grbAlgdel.Controls.Add(this.listCustom);
            this.grbAlgdel.ForeColor = System.Drawing.Color.Black;
            this.grbAlgdel.Location = new System.Drawing.Point(5, 30);
            this.grbAlgdel.Name = "grbAlgdel";
            this.grbAlgdel.Size = new System.Drawing.Size(305, 245);
            this.grbAlgdel.TabIndex = 3;
            this.grbAlgdel.TabStop = false;
            this.grbAlgdel.Text = "Create your Custom Erase Algorithm [Max 8 Values]...";
            // 
            // btnClearval
            // 
            this.btnClearval.ForeColor = System.Drawing.Color.Black;
            this.btnClearval.Location = new System.Drawing.Point(198, 74);
            this.btnClearval.Name = "btnClearval";
            this.btnClearval.Size = new System.Drawing.Size(100, 25);
            this.btnClearval.TabIndex = 3;
            this.btnClearval.Text = "button1";
            this.btnClearval.UseVisualStyleBackColor = true;
            // 
            // labScore
            // 
            this.labScore.AutoSize = true;
            this.labScore.ForeColor = System.Drawing.Color.Black;
            this.labScore.Location = new System.Drawing.Point(195, 25);
            this.labScore.Name = "labScore";
            this.labScore.Size = new System.Drawing.Size(35, 13);
            this.labScore.TabIndex = 283;
            this.labScore.Text = "label1";
            // 
            // BtnSug
            // 
            this.BtnSug.ForeColor = System.Drawing.Color.Black;
            this.BtnSug.Location = new System.Drawing.Point(198, 43);
            this.BtnSug.Name = "BtnSug";
            this.BtnSug.Size = new System.Drawing.Size(100, 25);
            this.BtnSug.TabIndex = 2;
            this.BtnSug.Text = "button1";
            this.BtnSug.UseVisualStyleBackColor = true;
            // 
            // rdbCust2
            // 
            this.rdbCust2.AutoSize = true;
            this.rdbCust2.ForeColor = System.Drawing.Color.Black;
            this.rdbCust2.Location = new System.Drawing.Point(198, 110);
            this.rdbCust2.Name = "rdbCust2";
            this.rdbCust2.Size = new System.Drawing.Size(86, 17);
            this.rdbCust2.TabIndex = 4;
            this.rdbCust2.TabStop = true;
            this.rdbCust2.Text = "User Method";
            this.rdbCust2.UseVisualStyleBackColor = true;
            // 
            // rdbCust1
            // 
            this.rdbCust1.AutoSize = true;
            this.rdbCust1.ForeColor = System.Drawing.Color.Black;
            this.rdbCust1.Location = new System.Drawing.Point(198, 140);
            this.rdbCust1.Name = "rdbCust1";
            this.rdbCust1.Size = new System.Drawing.Size(97, 17);
            this.rdbCust1.TabIndex = 5;
            this.rdbCust1.TabStop = true;
            this.rdbCust1.Text = "Classic Method";
            this.rdbCust1.UseVisualStyleBackColor = true;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(6, 218);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(185, 20);
            this.progressBar1.TabIndex = 279;
            // 
            // cmbCustom
            // 
            this.cmbCustom.ForeColor = System.Drawing.Color.Black;
            this.cmbCustom.FormattingEnabled = true;
            this.cmbCustom.Location = new System.Drawing.Point(6, 20);
            this.cmbCustom.Name = "cmbCustom";
            this.cmbCustom.Size = new System.Drawing.Size(185, 21);
            this.cmbCustom.TabIndex = 0;
            // 
            // listCustom
            // 
            this.listCustom.ForeColor = System.Drawing.Color.Black;
            this.listCustom.FormattingEnabled = true;
            this.listCustom.Location = new System.Drawing.Point(6, 43);
            this.listCustom.Name = "listCustom";
            this.listCustom.Size = new System.Drawing.Size(185, 173);
            this.listCustom.TabIndex = 1;
            // 
            // btnLoaddel
            // 
            this.btnLoaddel.ForeColor = System.Drawing.Color.Black;
            this.btnLoaddel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoaddel.Location = new System.Drawing.Point(10, 342);
            this.btnLoaddel.Name = "btnLoaddel";
            this.btnLoaddel.Size = new System.Drawing.Size(90, 25);
            this.btnLoaddel.TabIndex = 1;
            this.btnLoaddel.Text = "Load File...";
            this.btnLoaddel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLoaddel.UseVisualStyleBackColor = true;
            // 
            // labFilepathdel
            // 
            this.labFilepathdel.AutoSize = true;
            this.labFilepathdel.ForeColor = System.Drawing.Color.Black;
            this.labFilepathdel.Location = new System.Drawing.Point(8, 304);
            this.labFilepathdel.Name = "labFilepathdel";
            this.labFilepathdel.Size = new System.Drawing.Size(35, 13);
            this.labFilepathdel.TabIndex = 284;
            this.labFilepathdel.Text = "label1";
            // 
            // labKb
            // 
            this.labKb.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labKb.Location = new System.Drawing.Point(192, 342);
            this.labKb.Name = "labKb";
            this.labKb.Size = new System.Drawing.Size(80, 25);
            this.labKb.TabIndex = 285;
            this.labKb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grbDesc
            // 
            this.grbDesc.Controls.Add(this.labShrd);
            this.grbDesc.Location = new System.Drawing.Point(315, 30);
            this.grbDesc.Name = "grbDesc";
            this.grbDesc.Size = new System.Drawing.Size(247, 130);
            this.grbDesc.TabIndex = 287;
            this.grbDesc.TabStop = false;
            this.grbDesc.Text = "Description Algorithm:";
            // 
            // labShrd
            // 
            this.labShrd.ForeColor = System.Drawing.Color.Black;
            this.labShrd.Location = new System.Drawing.Point(5, 20);
            this.labShrd.Name = "labShrd";
            this.labShrd.Size = new System.Drawing.Size(237, 100);
            this.labShrd.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(320, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 288;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(320, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 289;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(320, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 290;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(320, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 291;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(320, 285);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 290;
            this.label5.Text = "label5";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 393);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grbDesc);
            this.Controls.Add(this.labKb);
            this.Controls.Add(this.labFilepathdel);
            this.Controls.Add(this.btnLoaddel);
            this.Controls.Add(this.grbAlgdel);
            this.Controls.Add(this.labTime);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.labOrtu);
            this.Controls.Add(this.txtFilepathdel);
            this.Controls.Add(this.btnDelete);
            this.Name = "FrmMain";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grbAlgdel.ResumeLayout(false);
            this.grbAlgdel.PerformLayout();
            this.grbDesc.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtFilepathdel;
        private System.Windows.Forms.Label labOrtu;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem infoMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeMenuItem;
        public System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labTime;
        private System.Windows.Forms.GroupBox grbAlgdel;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ComboBox cmbCustom;
        private System.Windows.Forms.ListBox listCustom;
        private System.Windows.Forms.RadioButton rdbCust2;
        private System.Windows.Forms.RadioButton rdbCust1;
        private System.Windows.Forms.Label labScore;
        private System.Windows.Forms.Button BtnSug;
        private System.Windows.Forms.Button btnLoaddel;
        private System.Windows.Forms.Button btnClearval;
        private System.Windows.Forms.Label labFilepathdel;
        private System.Windows.Forms.Label labKb;
        private System.Windows.Forms.GroupBox grbDesc;
        private System.Windows.Forms.Label labShrd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

