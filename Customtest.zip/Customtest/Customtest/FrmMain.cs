﻿//Copyright (C) 2007-2025 Mariano Ortu <https://www.sicurpas.it/> <https://www.speedcrypt.info/>

using System;
using System.IO;
using System.Linq;
using System.Drawing;
using CustomEraserLib;
using System.Threading;
using System.Reflection;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace Customtest
{
    public partial class FrmMain : Form
    {
        #region Constructors

        private DateTime _start = new DateTime();
        private OpenFileDialog openFileDialog1;
        private string _MB_SIZE = string.Empty;
        private bool _SUCC = false;
        public FrmMain()
        {
            InitializeComponent();
            LoadAll();
        }

        #endregion Constructors

        #region Settings
        void LoadAll()
        {
            // Form Settings
            Icon = Icon = Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
            Text = "Custom Erase Test...";
            StartPosition = FormStartPosition.CenterScreen;
            MaximizeBox = false;
            MinimizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            labOrtu.Text = "Copyright (C) 2007 - " + DateTime.Now.ToString("yyyy") + " Mariano Ortu";
                       
            // Other
            grbAlgdel.Text = "Create your Custom Erase Algorithm [Max 8 Values]...";
            grbAlgdel.ForeColor = Color.Brown;

            // ComboBox
            cmbCustom.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCustom.Cursor = Cursors.Hand;
            cmbCustom.Items.Add("Zero (0x00)");
            cmbCustom.Items.Add("One (0xFF)");
            cmbCustom.Items.Add("Random");
            cmbCustom.SelectedIndex = 0;
            
            // ListBox
            listCustom.BackColor = Color.Gainsboro;
            labScore.Text = "Score";
            labScore.ForeColor = Color.Blue;
            BtnSug.Text = "Suggest Algorithm";
            BtnSug.Cursor = cmbCustom.Cursor;
            btnClearval.Text = "Clear value List";
            btnClearval.Cursor = cmbCustom.Cursor;
            rdbCust1.Text = "Classic Method";
            rdbCust1.Cursor = cmbCustom.Cursor;
            rdbCust1.Checked = true;
            rdbCust2.Text = "User Method";
            rdbCust2.Cursor = cmbCustom.Cursor;
            grbDesc.TabStop = false;
            grbDesc.Text = "Algorithm Description:";
            grbDesc.ForeColor = Color.Brown;
            labShrd.Text = "Custom Erase by Mariano Ortu allows users to define a custom sequence of overwrite passes using zeros, ones, and random data." +
                           "The flexibility of this mode lets users balance between speed and security depending on their specific needs." +
                           "Best suited for advanced users who want full control over the erasure process.";
            
            label1.Text = "●  Blazing Fast and Secure";
            label2.Text = "●  Optimized for high Performance";
            label3.Text = "●  Deletes Files of any Type and Size";
            label4.Text = "●  Designed with a strong focus on Security";
            label5.Text = "●  Completely Free and Released Open Source";
            
            labFilepathdel.Text = "File Path:";
            btnLoaddel.Text = "Load File...";
            btnLoaddel.Cursor = cmbCustom.Cursor;
            btnDelete.Text = "Delete File";
            btnDelete.Cursor = cmbCustom.Cursor;
            btnDelete.Enabled = false;
            labKb.ForeColor = Color.Red;
            
            // File Dialog
            openFileDialog1 = new OpenFileDialog();

            // Events
            infoMenuItem.Click += InfoMenuItem_Click;
            closeMenuItem.Click += CloseMenuItem_Click;
            cmbCustom.SelectedIndexChanged += CmbCustom_SelectedIndexChanged;
            BtnSug.Click += BtnSug_Click;
            btnClearval.Click += BtnClearval_Click;
            rdbCust1.CheckedChanged += RdbCust1_CheckedChanged;
            rdbCust2.CheckedChanged += RdbCust2_CheckedChanged;
            txtFilepathdel.TextChanged += TxtFilepathdel_TextChanged;
            txtFilepathdel.MouseDown += TxtFilepathdel_MouseDown;
            btnLoaddel.Click += BtnLoaddel_Click;
            btnLoaddel.MouseMove += BtnLoaddel_MouseMove;
            btnLoaddel.MouseLeave += BtnLoaddel_MouseLeave;
            btnDelete.Click += BtnDelete_Click;
            timer1.Tick += Timer1_Tick;
        }
        
        #endregion Settings

        #region Events
        private void InfoMenuItem_Click(object sender, EventArgs e)
        {
            FrmInfo frm = new FrmInfo(this)
            {
                StartPosition = FormStartPosition.CenterScreen
            };
            frm.ShowDialog();
        }
        private void CloseMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void CmbCustom_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listCustom.Items.Count < 8)
            {
                listCustom.Items.Add(cmbCustom.SelectedItem.ToString());
                btnDelete.Enabled = labScore.Text.Contains("Strong") && File.Exists(txtFilepathdel.Text);
                Scorelist();
            }
        }
        private void BtnSug_Click(object sender, EventArgs e)
        {
            // Retrieve the suggested overwrite pattern sequence from the suggestion engine
            var suggestions = PassSuggestionEngine.GetSuggestedAlgorithm();

            // Clear any existing items in the custom pattern list
            listCustom.Items.Clear();

            // Populate the ListBox with the recommended overwrite patterns
            foreach (var suggestion in suggestions)
            {
                listCustom.Items.Add(suggestion);
            }

            // Calculate and display the effectiveness score of the selected sequence
            Scorelist();

            // If User Mode is selected and a valid file path exists, enable the Delete button
            if (rdbCust2.Checked && File.Exists(txtFilepathdel.Text))
                btnDelete.Enabled = true;
        }
        private void BtnClearval_Click(object sender, EventArgs e)
        {
            listCustom.Items.Clear();
            labScore.Text = "Score";
            progressBar1.Value = 0;
            if (rdbCust2.Checked) btnDelete.Enabled = false;
        }
        private void RdbCust1_CheckedChanged(object sender, EventArgs e)
        {
            if (File.Exists(txtFilepathdel.Text)) btnDelete.Enabled = true;
        }
        private void RdbCust2_CheckedChanged(object sender, EventArgs e)
        {
            if (listCustom.Items.Count == 0) btnDelete.Enabled = false;
        }
        private void TxtFilepathdel_TextChanged(object sender, EventArgs e)
        {
            if (File.Exists(txtFilepathdel.Text))
            {
                if (rdbCust1.Checked) btnDelete.Enabled = true;
                else
                if (rdbCust2.Checked)
                {
                    btnDelete.Enabled = labScore.Text.Contains("Strong") && File.Exists(txtFilepathdel.Text);
                }
            }
            else btnDelete.Enabled = false;
        }
        private void TxtFilepathdel_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                // Clear the default popup menu
                ContextMenuStrip cms = new ContextMenuStrip();
                txtFilepathdel.ContextMenuStrip = cms;
            }
        }
        private void BtnLoaddel_Click(object sender, EventArgs e)
        {
            try
            {
                _MB_SIZE = string.Empty;
                openFileDialog1.CheckFileExists = true;
                DialogResult fled = openFileDialog1.ShowDialog();
                if (fled == DialogResult.OK)
                {
                    txtFilepathdel.Text = openFileDialog1.FileName;
                    FileInfo fileInfo = new FileInfo(openFileDialog1.FileName);
                    _MB_SIZE = Math.Round(fileInfo.Length / (1024.0 * 1024.0), 2).ToString();
                }
            }
            finally
            {
                if(_MB_SIZE != string.Empty) labKb.Text = $"{_MB_SIZE} MB";
            }
        }
        private void BtnLoaddel_MouseMove(object sender, MouseEventArgs e)
        {
            txtFilepathdel.BackColor = Color.Yellow;
        }
        private void BtnLoaddel_MouseLeave(object sender, EventArgs e)
        {
            txtFilepathdel.BackColor = Color.White;
        }
        private async void BtnDelete_Click(object sender, EventArgs e)
        {
            await Deletefile();
        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan diff = DateTime.Now.Subtract(_start);
            labTime.Text = String.Format("{0:00}:{1:00}.{2:00}", diff.Minutes, diff.Seconds, diff.Milliseconds);
        }

        #endregion Events

        #region Procedures
        void Scorelist()
        {
            var items = listCustom.Items.Cast<string>();

            // Create the evaluator's application
            var evaluator = new CustomPassEvaluator(items);

            // Evaluate the strength
            var result = evaluator.EvaluateStrength();

            // Update UI
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 100;
            progressBar1.Value = result.VisualValue;

            labScore.Text = result.StrengthLabel;
        }
        void Start()
        {
            labTime.Text = "00.00.000";
            timer1.Enabled = true;
            _start = DateTime.Now;
            timer1.Start();
        }
        async Task Deletefile()
        {
            try
            {
                // Ask user for confirmation before proceeding with file deletion
                DialogResult result = MessageBox.Show("Do you really want to delete this File?", "Custom Erase Test", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.No)
                    return;  // Exit if user cancels the operation

                _SUCC = false; // Reset success flag before starting the erase operation
                Customenab(false);
                btnDelete.Enabled = false;
                Start(); // Start Timer

                // Run the file erase operation asynchronously to avoid UI blocking
                await Task.Run(() =>
                {
                    if (rdbCust1.Checked)
                    {
                        // Perform secure erase with a predefined sequence of passes
                        bool success = CustomEraser.SecureErase(txtFilepathdel.Text, new[] { CustomPassType.Random, CustomPassType.Zeros, CustomPassType.Ones });
                        
                        if (success) _SUCC = true;  // Set success flag if operation succeeded
                    }
                    else if (rdbCust2.Checked)
                    {
                        // Call method that performs custom erase based on user selection
                        CallCustomEraseFromListBox();
                    }
                });
            }
            finally
            {
                // Stop and disable the timer regardless of success or failure
                timer1.Stop();
                timer1.Enabled = false;
                txtFilepathdel.Text = string.Empty;
                // Show the final result message based on the success flag
                if (_SUCC == true) MessageBox.Show("Secure Erase completed successfully!", "Custom Erase Test", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else MessageBox.Show("Secure Erase failed!", "Custom Erase Test", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Customenab(true);
            }
        }
        void CallCustomEraseFromListBox()
        {
            // Retrieve the file path from the input textbox.
            string filePath = txtFilepathdel.Text;

            // Validate the file path: check for null/empty and file existence.
            if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
            {
                MessageBox.Show("Invalid file path.", "Custom Erase Test", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Initialize a list to hold the selected custom pass sequence.
            List<CustomPassType> passSequence = new List<CustomPassType>();

            // Parse each item in the custom pass list and add it to the sequence if valid.
            foreach (var item in listCustom.Items)
            {
                if (Enum.TryParse(item.ToString(), true, out CustomPassType pass))
                    passSequence.Add(pass);
            }

            // If no valid pass types were selected, show a warning and exit.
            if (passSequence.Count == 0)
            {
                MessageBox.Show("No custom pass selected.", "Custom Erase Test", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Perform secure erase using the selected pass sequence.
            bool result = CustomEraser.SecureErase(filePath, passSequence.ToArray(), CancellationToken.None);

            // Set the success flag if erase was successful.
            if (result) _SUCC = true;
        }
        void Customenab(bool State)
        {
            menuStrip1.Enabled = State;
            grbAlgdel.Enabled = State;
            txtFilepathdel.Enabled = State;
            btnLoaddel.Enabled = State;
        }

        #endregion Procedures
    }
}