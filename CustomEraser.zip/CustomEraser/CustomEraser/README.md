# Custom Erase – Secure File Deletion Algorithm

**Author:** Mariano Ortu  
**Website:** https://www.sicurpas.it  
**Email:** sicurpas@sicurpas.it  
**License:** GNU GPL v3 or later  

## Overview

Custom Erase is a secure file deletion algorithm designed to permanently and irreversibly remove data from both HDDs and SSDs.

This package includes:

- Full C# source code of the algorithm
- Visual Studio project to build the DLL (CustomEraser.dll)
- Demo application (CustomTest) demonstrating usage of the DLL
- SHA-256 checksum and PGP signature files
- GNU GPL v3 license

## Requirements

- Microsoft Visual Studio 2019 or later
- .NET Framework 4.8

## Build Instructions

1. Extract the `CustomEraserdll.zip` archive.
2. Open the `CustomEraser.csproj` file in Visual Studio.
3. Build the project in *Release* mode.
4. The DLL will be located in `bin\Release\CustomEraser.dll`.

## Usage

The `CustomTest` demo application shows how to:

- Import and reference the DLL in a C# project
- Pass the file path for secure deletion
- Handle success or failure responses

## Verification

Use the included `.sha256` and `.sig` files to verify the integrity and authenticity of the contents.

## License

This project is released under the GNU General Public License v3.0 or later.  
See the `LICENSE` file for full license terms.
